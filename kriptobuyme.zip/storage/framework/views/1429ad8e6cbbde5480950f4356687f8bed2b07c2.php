

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Ticket</h6>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr class="small">
							<th>S/N</th>
							<th>USERNAME</th>
							<th>PRIORITY</th>
							<th>TICKET ID</th>
							<th>STATUS</th>
							<th>SUBJECT</th>
							<th>CREATED</th>
							<th>UPDATED</th>
							<th></th>
						</tr>
					</thead>
					<tfoot>
						<tr class="small">
							<th>S/N</th>
							<th>USERNAME</th>
							<th>PRIORITY</th>
							<th>TICKET ID</th>
							<th>STATUS</th>
							<th>SUBJECT</th>
							<th>CREATED</th>
							<th>UPDATED</th>
							<th></th>
						</tr>
					</tfoot>
					<tbody class="small">
						<?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($ticket['id']); ?></td>
							<td><?php echo e($ticket->user->username); ?></td>
							<td><?php echo e($ticket['priority']); ?></td>
							<td><?php echo e($ticket['ticket_id']); ?></td>
							<td><span class="badge badge-<?php echo e($ticket['status'] == 'Open' ? 'primary' : 'danger'); ?> p-2"><?php echo e($ticket['status']); ?></span></td>
							<td><?php echo e($ticket['subject']); ?></td>
							<td><?php echo e($ticket['created_at']); ?></td>
							<td><?php echo e($ticket['updated_at']); ?></td>
							<td>
								<div class="dropdown no-arrow">
									<a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink"
										data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
									</a>
									<div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
										aria-labelledby="dropdownMenuLink">
										<a class="dropdown-item" href="<?php echo e(route('admin.tickets.edit', ['id' => $ticket['id']])); ?>">Manage Ticket</a>
										<?php if($ticket['status'] == 'Closed'): ?>
											<form action="<?php echo e(route('admin.ticket.open', $ticket['id'])); ?>" method="POST">
												<?php echo csrf_field(); ?>
												<button type="submit" class="dropdown-item" href="#">Re-Open</button>
											</form>
										<?php endif; ?>
										<?php if($ticket['status'] == 'Open'): ?>
											<form action="<?php echo e(route('admin.ticket.close', $ticket['id'])); ?>" method="POST">
												<?php echo csrf_field(); ?>
												<button type="submit" class="dropdown-item" href="#">Close</button>
											</form>
										<?php endif; ?>
										<form action="<?php echo e(route('admin.ticket.delete', $ticket['id'])); ?>" method="POST">
											<?php echo csrf_field(); ?>
											<?php echo method_field('DELETE'); ?>;
											<button type="submit" class="dropdown-item" href="#">Delete</button>
										</form>
									</div>
								</div>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/admin/tickets.blade.php ENDPATH**/ ?>