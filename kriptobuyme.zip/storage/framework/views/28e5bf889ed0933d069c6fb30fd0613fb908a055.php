

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="row">
		<!-- Earnings (Monthly) Card Example -->
		<?php $__currentLoopData = $deposit_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-xl-3 col-md-6 mb-4">
			<div class="card border-left-primary shadow h-100 py-2">
				<div class="card-body">
					<div class="row no-gutters align-items-center">
						<div class="col mr-2">
							<div class="text-xs font-weight-bold text-primary text-uppercase mb-1"><?php echo e($deposit_method['display_name']); ?></div>
							<div class="txt-sm mb-0 font-weight-bold text-gray-800">Limit: $<?php echo e(number_format($deposit_method['min'])); ?> - $<?php echo e(number_format($deposit_method['max'])); ?></div>
							<div class="txt-sm mb-0 font-weight-bold text-gray-800">Charge: $<?php echo e($deposit_method['fixed_charge_amount']); ?> + <?php echo e(number_format($deposit_method['percentage_charge'])); ?>%</div>
						</div>
						<div class="col-auto">
							<i class="fas fa-dice-d6 fa-2x text-gray-300"></i>
						</div>
					</div>
					<a href="#" class="btn btn-primary btn-icon-split mt-3" data-toggle="modal" data-target="#deposit<?php echo e($deposit_method['id']); ?>">
						<span class="icon small text-white-50">
							 <i class="fas fa-plus"></i>
						</span>
						<span class="text small">Deposit</span>
				  </a>
				</div>
			</div>
		</div>	 
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>

	<div class="card shadow mb-4">
		<div class="card-header py-3">
			<h6 class="m-0 font-weight-bold text-primary">Deposit logs</h6>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
					<thead>
						<tr class="small">
							<th>S/N</th>
							<th>REFERANCE ID</th>
							<th>AMOUNT</th>
							<th>METHOD</th>
							<th>STATUS</th>
							<th>CHARGE</th>
							<th>CREATED</th>
							<th>UPDATED</th>
						</tr>
					</thead>
					<tfoot>
						<tr class="small">
							<th>S/N</th>
							<th>REFERANCE ID</th>
							<th>AMOUNT</th>
							<th>METHOD</th>
							<th>STATUS</th>
							<th>CHARGE</th>
							<th>CREATED</th>
							<th>UPDATED</th>
						</tr>
					</tfoot>
					<tbody class="small">
						<?php $__currentLoopData = $user_deposits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_deposit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($user_deposit['id']); ?></td>
								<td><?php echo e($user_deposit['reference_id']); ?></td>
								<td>$<?php echo e(number_format($user_deposit['amount'])); ?></td>
								<td><?php echo e($user_deposit->depositMethod->display_name); ?></td>
								<td><?php echo e($user_deposit['status']); ?></td>
								<td>$<?php echo e(number_format($user_deposit['deposit_charge'])); ?></td>
								<td><?php echo e($user_deposit['created_at']); ?>	</td>
								<td><?php echo e($user_deposit['updated_at']); ?>	</td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>


<?php $__currentLoopData = $deposit_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deposit_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="deposit<?php echo e($deposit_method['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content py-3">
			<form action="<?php echo e(route('user.deposit.preview')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="text" name="deposit_method" value="<?php echo e($deposit_method['id']); ?>" hidden>
				<p class="mx-auto text-center text-dark font-weight-bold">Deposit With <?php echo e($deposit_method['display_name']); ?></p>
				<div class="row py-2">
					<i class="fas fa-dice-d6 text-gray-300 mx-auto" style="font-size:57px !important;"></i>
				</div>
				<div class="form-group px-5 mt-5 row">
					<input type="number" max="<?php echo e(number_format($deposit_method['max'])); ?>" min="<?php echo e($deposit_method['min']); ?>" placeholder="Enter Amount" name="amount" class="form-control no-outline mx-auto" style="width:70%;border: none; border-bottom:1px solid black; border-radius:0px;">
				</div>
				<div class="row mt-5 py-3 ">
					<button type="submit" class="btn btn-primary btn-sm mx-auto">Preview</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/deposit.blade.php ENDPATH**/ ?>