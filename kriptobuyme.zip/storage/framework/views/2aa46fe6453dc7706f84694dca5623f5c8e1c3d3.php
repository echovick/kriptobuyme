<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>User Dashboard</title>

		<!-- Custom fonts for this template-->
		<link href="<?php echo e(asset('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
		<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

		<!-- Custom styles for this template-->
		<link href="<?php echo e(asset('assets/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
		<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

		<!-- Custom styles for page -->
		<link href="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">

	</head>

	<body id="page-top">

		<!-- Page Wrapper -->
		<div id="wrapper">

			<!-- Sidebar -->
			<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

				<!-- Sidebar - Brand -->
				<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
					<div class="sidebar-brand-text mx-3">Kriptobuyme Admin</div>
				</a>

				<!-- Divider -->
				<hr class="sidebar-divider my-0">

				<!-- Nav Item - Dashboard -->
				<li class="nav-item <?php echo e(request()->is('admin') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="fas fa-fw fa-tachometer-alt"></i>
						<span>Dashboard</span></a>
				</li>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					Client
				</div>

				<li class="nav-item <?php echo e(request()->is('admin/customers') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('admin.customers')); ?>">
						<i class="fas fa-fw fa-users"></i>
						<span>Customers</span></a>
				</li>
				<li class="nav-item <?php echo e(request()->is('admin/tickets') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('admin.tickets')); ?>">
						<i class="fas fa-fw fa-ticket-alt"></i>
						<span>Support Tickets</span></a>
				</li>
				<li class="nav-item <?php echo e(request()->is('admin/promotional-emails') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('admin.promotional-emails')); ?>">
						<i class="fas fa-fw fa-mail-bulk"></i>
						<span>Promotional Emails</span></a>
				</li>
				<li class="nav-item <?php echo e(request()->is('admin/messages') ? 'active' : ''); ?>">
					<a class="nav-link" href="<?php echo e(route('admin.messages')); ?>">
						<i class="fas fa-fw fa-envelope"></i>
						<span>Messages</span></a>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item <?php echo e((request()->is('admin/payment-gateways') || request()->is('admin/bank-transfer') || request()->is('admin/deposit-logs')) ? 'active' : ''); ?>">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse1"
						aria-expanded="true" aria-controls="collapse1">
						<i class="fas fa-fw fa-wallet"></i>
						<span>Deposit</span>
					</a>
					<div id="collapse1" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item <?php echo e(request()->is('admin/payment-gateways') ? 'active' : ''); ?>" href="<?php echo e(route('admin.payment-gateways')); ?>">Payment Gateways</a>
							<a class="collapse-item <?php echo e(request()->is('admin/bank-transfer') ? 'active' : ''); ?>" href="<?php echo e(route('admin.bank-transfer')); ?>">Bank Transfer & logs</a>
							<a class="collapse-item <?php echo e(request()->is('admin/deposit-logs') ? 'active' : ''); ?>" href="<?php echo e(route('admin.deposit-logs')); ?>">Deposit logs</a>
						</div>
					</div>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item <?php echo e(request()->is('admin/payout-methods') || request()->is('admin/payout-logs') ? 'active' : ''); ?>">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse2"
						aria-expanded="true" aria-controls="collapse2">
						<i class="fas fa-fw fa-money-check"></i>
						<span>Payout</span>
					</a>
					<div id="collapse2" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item <?php echo e(request()->is('admin/payout-methods') ? 'active' : ''); ?>" href="<?php echo e(route('admin.payout-methods')); ?>">Payout Types</a>
							<a class="collapse-item <?php echo e(request()->is('admin/payout-logs') ? 'active' : ''); ?>" href="<?php echo e(route('admin.payout-logs')); ?>">Withdraw Log</a>
						</div>
					</div>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item <?php echo e((request()->is('admin/open-trades') || request()->is('admin/closed-trades') || request()->is('admin/plans-settings') || request()->is('admin/coupons')) ? 'active' : ''); ?>">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse3"
						aria-expanded="true" aria-controls="collapse3">
						<i class="fas fa-fw fa-hand-holding-usd"></i>
						<span>Investment</span>
					</a>
					<div id="collapse3" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item <?php echo e(request()->is('admin/open-trades') ? 'active' : ''); ?>" href="<?php echo e(route('admin.open-trades')); ?>">Open Trades</a>
							<a class="collapse-item <?php echo e(request()->is('admin/closed-trades') ? 'active' : ''); ?>" href="<?php echo e(route('admin.closed-trades')); ?>">Closed Trades</a>
							<a class="collapse-item <?php echo e(request()->is('admin/plans-settings') ? 'active' : ''); ?>" href="<?php echo e(route('admin.plans-settings')); ?>">Plans</a>
							<a class="collapse-item <?php echo e(request()->is('admin/coupons') ? 'active' : ''); ?>" href="<?php echo e(route('admin.coupons')); ?>">Coupon</a>
						</div>
					</div>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item <?php echo e(request()->is('admin/transfer-logs') || request()->is('admin/referal-earnings') ? 'active' : ''); ?>" href="<?php echo e(route('admin.open-trades')); ?>">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse4"
						aria-expanded="true" aria-controls="collapse4">
						<i class="fas fa-fw fa-share"></i>
						<span>Transfer</span>
					</a>
					<div id="collapse4" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item <?php echo e(request()->is('admin/transfer-logs') ? 'active' : ''); ?>" href="<?php echo e(route('admin.transfer-logs')); ?>" href="<?php echo e(route('admin.transfer-logs')); ?>">Transfer Logs</a>
							<a class="collapse-item <?php echo e(request()->is('admin/referal-earnings') ? 'active' : ''); ?>" href="<?php echo e(route('admin.open-trades')); ?>" href="<?php echo e(route('admin.referal-earnings')); ?>">Referral Earnings</a>
						</div>
					</div>
				</li>

				<!-- Divider -->
				<hr class="sidebar-divider">

				<!-- Heading -->
				<div class="sidebar-heading">
					More
				</div>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse5"
						aria-expanded="true" aria-controls="collapse5">
						<i class="fas fa-fw fa-blog"></i>
						<span>Blog</span>
					</a>
					<div id="collapse5" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item" href="<?php echo e(route('admin.blog-articles')); ?>">Articles</a>
							<a class="collapse-item" href="<?php echo e(route('admin.blog-categories')); ?>">Category</a>
						</div>
					</div>
				</li>

				<!-- Nav Item - Pages Collapse Menu -->
				<li class="nav-item">
					<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapse6"
						aria-expanded="true" aria-controls="collapse6">
						<i class="fas fa-fw fa-globe"></i>
						<span>Website Design</span>
					</a>
					<div id="collapse6" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
						<div class="bg-white py-2 collapse-inner rounded">
							<a class="collapse-item" href="<?php echo e(route('admin.homepage')); ?>">Homepage</a>
							<a class="collapse-item" href="<?php echo e(route('admin.logo-settings')); ?>">Logo & Favicon</a>
							<a class="collapse-item" href="<?php echo e(route('admin.reviews')); ?>">Platform Review</a>
							<a class="collapse-item" href="<?php echo e(route('admin.services')); ?>">Services</a>
							<a class="collapse-item" href="<?php echo e(route('admin.team')); ?>">Team</a>
							<a class="collapse-item" href="<?php echo e(route('admin.pages')); ?>">Webpages</a>
							<a class="collapse-item" href="<?php echo e(route('admin.faqs')); ?>">FAQs</a>
							<a class="collapse-item" href="<?php echo e(route('admin.currency')); ?>">Currency</a>
							<a class="collapse-item" href="<?php echo e(route('admin.terms')); ?>">Terms & Conditions</a>
							<a class="collapse-item" href="<?php echo e(route('admin.privacy-policy')); ?>">Privacy Policy</a>
							<a class="collapse-item" href="<?php echo e(route('admin.about-us')); ?>">About Us</a>
							<a class="collapse-item" href="<?php echo e(route('admin.social-links')); ?>">Social Links</a>
						</div>
					</div>
				</li>

				<li class="nav-item">
					<a class="nav-link" href="<?php echo e(route('admin.settings')); ?>">
						<i class="fas fa-fw fa-cog"></i>
						<span>Settings</span></a>
				</li>

				<li class="nav-item">
					<a class="nav-link" href="/admin/logout">
						<i class="fas fa-fw fa-sign-out-alt"></i>
						<span>Sign Out</span></a>
				</li>


				<!-- Divider -->
				<hr class="sidebar-divider d-none d-md-block">

				<!-- Sidebar Toggler (Sidebar) -->
				<div class="text-center d-none d-md-inline">
					<button class="rounded-circle border-0" id="sidebarToggle"></button>
				</div>

			</ul>
			<!-- End of Sidebar -->

			<!-- Content Wrapper -->
			<div id="content-wrapper" class="d-flex flex-column">

				<!-- Main Content -->
				<div id="content">

					<!-- Topbar -->
					<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

						<!-- Sidebar Toggle (Topbar) -->
						<button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
							<i class="fa fa-bars"></i>
						</button>

						<!-- Topbar Navbar -->
						<ul class="navbar-nav ml-auto">

							<div class="topbar-divider d-none d-sm-block"></div>

							<!-- Nav Item - User Information -->
							<li class="nav-item dropdown no-arrow">
								<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
									data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
									<span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(auth()->user()->name); ?></span>
									<img class="img-profile rounded-circle" src="../assets/img/undraw_profile.svg">
								</a>
								<!-- Dropdown - User Information -->
								<div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
									aria-labelledby="userDropdown">
									<a class="dropdown-item" href="#">
										<i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
										Profile
									</a>
									<a class="dropdown-item" href="#">
										<i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
										Settings
									</a>
									<a class="dropdown-item" href="#">
										<i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
										Activity Log
									</a>
									<div class="dropdown-divider"></div>
									<a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
										<i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
										Logout
									</a>
								</div>
							</li>

						</ul>

					</nav>
					<!-- End of Topbar -->

					<!-- Begin Page Content -->
					
					<?php echo $__env->yieldContent('content'); ?>

					<!-- /.container-fluid -->

				</div>
				<!-- End of Main Content -->

				<!-- Footer -->
				<footer class="sticky-footer bg-white">
					<div class="container my-auto">
						<div class="copyright text-center my-auto">
							<span>Copyright &copy; Your Website 2020</span>
						</div>
					</div>
				</footer>
				<!-- End of Footer -->

			</div>
			<!-- End of Content Wrapper -->

		</div>
		<!-- End of Page Wrapper -->

		<!-- Scroll to Top Button-->
		<a class="scroll-to-top rounded" href="#page-top">
			<i class="fas fa-angle-up"></i>
		</a>

		<!-- Logout Modal-->
		<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
			aria-hidden="true">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
						<button class="close" type="button" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">×</span>
						</button>
					</div>
					<div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
					<div class="modal-footer">
						<button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
						<a class="btn btn-primary" href="login.html">Logout</a>
					</div>
				</div>
			</div>
		</div>

		<!-- Bootstrap core JavaScript-->
		<script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

		<!-- Core plugin JavaScript-->
		<script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

		<!-- Custom scripts for all pages-->
		<script src="<?php echo e(asset('assets/js/sb-admin-2.min.js')); ?>"></script>

		<!-- Page level plugins -->
		<script src="<?php echo e(asset('assets/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('assets/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

		<!-- Page level custom scripts -->
		<script src="<?php echo e(asset('assets/js/demo/datatables-demo.js')); ?>"></script>

	</body>

</html><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/layouts/admin.blade.php ENDPATH**/ ?>