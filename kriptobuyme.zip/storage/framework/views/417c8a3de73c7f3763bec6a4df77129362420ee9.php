

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card bg-light text-black shadow mb-3">
		<div class="card-body">
			<p class="font-weight-bold">Deposit Request Sent Successfully</p>
			<div class="text-black-50 small">You're to pay $<?php echo e($amount); ?>,  equvalent of <?php echo e($deposit_method_details['display_name']); ?> to the address: <?php echo e($deposit_method_details['method_address']); ?></div>
			<a class="btn btn-primary btn-sm mt-3" href="<?php echo e(route('user.deposit')); ?>">Ok</a>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/confirm-deposit.blade.php ENDPATH**/ ?>