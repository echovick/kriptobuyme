

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<?php if(isset($_GET['message']) && $_GET['message'] == 'successfull'): ?>
		<div class="alert alert-success">
			Trade Created Successfully
		</div>
	<?php endif; ?>
	<div class="row mt-3">
		<div class="col-md-8">
			<div class="row">
				<?php $__currentLoopData = $user_trades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_trade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6">
					<div class="card mb-4 py-3 border-bottom-primary">
						<div class="card-body small">
							<span class="txt-md font-weight-bold">#<?php echo e($user_trade['reference_id']); ?> </span><br><br>
							Plan: <?php echo e($user_trade->plan->plan_name); ?> <br>
							Started: <?php echo e($user_trade['created_at']); ?><br>
							Deposit: $<?php echo e(number_format($user_trade['amount'])); ?><br>
							Percent: <?php echo e(number_format($user_trade['daily_percentage'])); ?>% <br>
							Duration: <?php echo e(number_format($user_trade['trade_duration'])); ?> Day(s)<br>
							Type: <?php echo e($user_trade['trade_source']); ?><br>
							End: <?php echo e($user_trade['trade_end_date']); ?><br><br>
							<?php echo e($user_trade['trade_profit']); ?>USD/<?php echo e(($user_trade['daily_percentage'] / 100 * $user_trade['amount']) * $user_trade['trade_duration']); ?> + Trading Bonus $<?php echo e($user_trade['trade_bonus']); ?>

						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card shadow mb-4">
				<!-- Card Header - Dropdown -->
				<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
					<h6 class="m-0 font-weight-bold text-primary">Top Earners</h6>
					
				</div>
				<!-- Card Body -->
				<div class="card-body">
					<?php $__currentLoopData = $top_earners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_earner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(number_format($top_earner['profit'])): ?>
					<div class="d-flex mb-3">
						<img class="img-profile rounded-circle w-100 col-3" src="../assets/img/undraw_profile.svg">
						<p class="mr-2 d-none align-self-center d-lg-inline text-gray-600 small"><?php echo e($top_earner['username']); ?><br>$<?php echo e(number_format($top_earner['profit'])); ?></p>
					</div>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="card mb-4 py-3 border-bottom-primary">
				<div class="card-body small">
					<span class="txt-md font-weight-bold">Your Statistics</span><br><br>
					Highest Amount: $<?php echo e(number_format($highest_amount)); ?> <br>
					Lowest Amount: $<?php echo e(number_format($lowest_amount)); ?> <br>
					Total Amount: $<?php echo e(number_format($total_amount)); ?><br>
					Highest Profit: $<?php echo e(number_format($highest_profit)); ?> <br>
					Lowest Profit: $<?php echo e(number_format($lowest_profit)); ?><br>
					Total Profit: $<?php echo e(number_format($total_profit)); ?><br>
					Highest Bonus: $<?php echo e(number_format($highest_bonus)); ?><br>
					Lowest Bonus: $<?php echo e(number_format($lowest_bonus)); ?><br>
					Total Bonus: $<?php echo e(number_format($total_bonus)); ?>

				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/trade-activity.blade.php ENDPATH**/ ?>