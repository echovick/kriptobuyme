<?php
use App\Models\Admin;
?>


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="card bg-light text shadow mb-3">
		<div class="card-body">
			<div class="row">
				<div class="col-md-6">
					<h5 class="px-3">Log</h5>
					<ul class="timeline">
						<?php
							$content = $this_ticket->content;
							$content = unserialize($content);
						?>
						<?php if(is_array($content) && count($content) > 0): ?>
							<?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
								$user_type = $item['user_type'];
								$user_id = $item['user_id'];
								$message = $item['message'];
								$timestamp = $item['timestamp'];
								$timestamp = date_create($timestamp);

								if($user_type == 'User'){
									$user = Admin::find($user_id)->first();
									$name = $user->username;
								}else{
									$name = auth()->user()->name;
								}
							?>
							<li>
								<a target="_blank" href="#" class="text"><?php echo e(strtoupper($name)); ?></a>
								<a href="#" class="float-right small"><?php echo e(date_format($timestamp, 'D M, Y h:m a')); ?></a>
								<p class="txt-md"><?php echo e($message); ?></p>
							</li>								
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="card bg-light shadow">
		<div class="card-body">
			<h5>Reply</h5>
			<form action="<?php echo e(route('admin.ticket.update', $this_ticket->id)); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<input type="text" name="user_type" value="Admin" hidden>
				<input type="text" name="user_id" value="<?php echo e(auth()->user()->id); ?>" id="" hidden>
				<div class="mb-3">
					<label for="" class="font-weight-bold small">Message</label>
					<div class="row">
						<div class="col">
							<textarea class="form-control" rows="5" id="comment" name="message" placeholder="Enter Your Message?"></textarea>
						</div>
					</div>
				</div>
				<div class="row mt-5">
					<button type="submit" href="#" class="btn btn-primary btn-icon-split shadow ml-auto">
						<span class="icon txt-sm text-white-50">
							<i class="fas fa-check-double"></i>
						</span>
						<span class="txt-sm text">Send</span>
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/admin/manage-ticket.blade.php ENDPATH**/ ?>