

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<?php if(isset($_GET['message']) && $_GET['message'] == 'successfull'): ?>
		<div class="alert alert-info">
			Withdrwal Request Created Successfully
		</div>
	<?php elseif(isset($_GET['message']) && $_GET['message'] == 'insufficient_amount'): ?>
		<div class="alert alert-info">
			Insufficent Balance
		</div>
	<?php endif; ?>
	<div class="row ml-2">
		<a href="#" class="btn btn-primary btn-icon-split shadow" data-toggle="modal" data-target="#withdrawal">
			<span class="icon txt-sm text-white-50">
				<i class="fas fa-plus"></i>
			</span>
			<span class="txt-sm text">Create Withdrawal Request</span>
		</a>
	</div>
	<div class="row mt-3">
		<div class="col-md-8">
			<div class="row">
				<?php $__currentLoopData = $user_withdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-6">
						<div class="card mb-4 py-3 border-bottom-primary">
							<div class="card-body small">
								<span class="txt-md font-weight-bold">#<?php echo e($user_withdrawal['reference_id']); ?> </span><br><br>
								Amount: $<?php echo e(number_format($user_withdrawal['amount'])); ?> <br>
								Charge: $<?php echo e(number_format($user_withdrawal['charge'])); ?><br>
								Method: <?php echo e($user_withdrawal->withdrwalMethod->name ?? ''); ?><br>
								Details: <?php echo e($user_withdrawal['address_details']); ?> <br>
								Status: <?php echo e($user_withdrawal['status']); ?><br>
								Type: <?php echo e($user_withdrawal['type']); ?><br>
								Created: <?php echo e($user_withdrawal['created_at']); ?><br>
								Updated: <?php echo e($user_withdrawal['updated_at']); ?><br>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card shadow mb-4 rounded-1">
				<div class="card-header py-3">
					<h6 class="m-0 font-weight-bold text-primary text-center">Total Statistics</h6>
					<div class="text-center mt-4">
						<p class="small"><i class="fas fa-google-wallet mr-1"></i> Received<br>
							<span class="text-lg font-weight-bold">USD <?php echo e(number_format($total_deposit)); ?></span>
						</p>
					</div>
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-6">
							Pending
						</div>
						<div class="col-6 text-right text-primary">
							USD <?php echo e(number_format($pending_deposit)); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-6">
							Total
						</div>
						<div class="col-6 text-right text-primary">
							USD <?php echo e(number_format($total_deposit)); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="withdrawal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content py-3">
			<h5 class="text-center py-2">Withdrawal Request</h5>
			<form action="<?php echo e(route('user.withdrawal.create')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="form-group mx-5">
					<label for="">Amount:</label>
					<input type="text" name="amount" class="form-control form-control-sm small" placeholder="Enter Amount to withdraw">
				</div>
				<div class="form-group mx-5">
					<label for="">Type:</label>
					<select name="withdrawal_type" class="form-control form-control-sm small" id="">
						<option value="NULL">Select</option>
						<option value="profit">Trading Profit</option>
						<option value="balance">Account Balance</option>
						<option value="referal">Referal Earnings</option>
					</select>
				</div>
				<div class="form-group mx-5">
					<label for="">Method:</label>
					<select name="withdrawal_method" class="form-control form-control-sm small" id="">
						<option value="0">Select</option>
						<?php $__currentLoopData = $withdrawal_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($withdrawal_method['id']); ?>"><?php echo e($withdrawal_method['name']); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</div>
				<div class="form-group mx-5">
					<label for="">Detials</label>
					<input type="text" class="form-control form-control-sm small" name="address_details" placeholder="Enter payout address details i.e: kijhuytfrweeawsedrtfyuijhytgrf	">
				</div>
				<div class="row mt-5 py-3 ">
					<button type="submit" class="btn btn-primary btn-sm mx-auto">Confirm</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/withdrawal.blade.php ENDPATH**/ ?>