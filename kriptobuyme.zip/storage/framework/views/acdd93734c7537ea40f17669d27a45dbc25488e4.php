

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<?php if(isset($_GET['message']) && $_GET['message'] == 'insufficient_amount'): ?>
	<div class="alert alert-info">
		You do not have sufficent balance to make this transfer
	</div>		 
	<?php endif; ?>
	<div class="row ml-2">
		<a href="#" class="btn btn-primary btn-icon-split shadow" data-toggle="modal" data-target="#transfer">
			<span class="icon txt-sm text-white-50">
				<i class="fas fa-plus"></i>
			</span>
			<span class="txt-sm text">Send Money</span>
		</a>
	</div>
	<div class="row mt-3">
		<div class="col-md-8">
			<div class="row">
				<?php $__currentLoopData = $user_transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6">
					<div class="card mb-4 py-3 border-bottom-primary">
						<div class="card-body small">
							<span class="txt-md font-weight-bold">#<?php echo e($user_transfer['reference_id']); ?> </span><br><br>
							Amount: $<?php echo e(number_format($user_transfer['amount'])); ?> <br>
							Charge: $<?php echo e(number_format($user_transfer['charge'])); ?><br>
							Email: <?php echo e($user_transfer->receiver->username); ?><br>
							Status: <?php echo e($user_transfer['status']); ?> <br>
							Created: <?php echo e($user_transfer['created_at']); ?><br>
							Updated: <?php echo e($user_transfer['updated_at']); ?><br>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="col-md-4">
			<div class="card shadow mb-4 rounded-1">
				<div class="card-header py-3">
					<h6 class="m-0 font-weight-bold text-primary text-center">Total Statistics</h6>
					<div class="text-center mt-4">
						<p class="small"><i class="fas fa-google-wallet mr-1"></i> Sent<br>
							<span class="text-lg font-weight-bold">USD <?php echo e(number_format($total_sent)); ?></span>
						</p>
					</div>
				</div>
				<div class="card-body">
					<div class="row">
						<div class="col-6">
							Pending
						</div>
						<div class="col-6 text-right text-primary">
						USD <?php echo e(number_format($total_pending)); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-6">
							Returned
						</div>
						<div class="col-6 text-right text-primary">
							USD <?php echo e(number_format($total_returned)); ?>

						</div>
					</div>
					<div class="row">
						<div class="col-6">
							Total
						</div>
						<div class="col-6 text-right text-primary">
							USD <?php echo e(number_format($total_sent)); ?>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<div class="modal fade" id="transfer" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content py-3">
			<form action="<?php echo e(route('user.transfer.new')); ?>" method="POST" class="px-5">
				<?php echo csrf_field(); ?>
				<p class="mx-auto text-center text-dark font-weight-bold">Transfer Money</p>
				<p class="mx-auto text-center text-dark font-weight-bold small">Trasfer Charge is 5% per transaction, if user is not a member of this platform, registration is required to claim the money, money will be refunded after 5 days if the money is not claimed</p>
				<div class="form-group px-5 mt-5 row">
					<span>Email: </span>
					<input type="email" class="px-1 mx-2" name="email" placeholder="" style="border:none; outline:none; border-bottom:1px solid rgb(78, 78, 78); width:70%;" required>
				</div>
				<div class="form-group px-5 mt-5 row">
					<span>Amount: </span>
					<input type="number" class="px-1 mx-2" name="amount" placeholder="" style="border:none; outline:none; border-bottom:1px solid rgb(78, 78, 78); width:70%;">
				</div>
				<div class="row mt-5 py-3 ">
					<button type="submit" class="btn btn-primary btn-sm mx-auto">Transfer</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/transfer.blade.php ENDPATH**/ ?>