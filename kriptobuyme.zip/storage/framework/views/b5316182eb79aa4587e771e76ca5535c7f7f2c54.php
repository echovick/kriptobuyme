

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div class="alert alert-info">
		Payouts wont be available till end of plan duration. Interest means profit and compound is sum
		of money invested plus profit. Trading bonus is a certain percent of your compound interest. If
		interest reads minus, dont invest, you will lose money
	</div>
	
	<?php if(isset($_GET['message']) && $_GET['message'] == 'unsuccessful'): ?>
		<div class="alert alert-danger">
			You do not have sufficient amount in your balance
		</div>
	<?php endif; ?>
	<div class="row mt-3">
		<div class="col-md-12">
			<div class="row">
				<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-3">
					<div class="card mb-4 py-3 border-bottom-primary">
						<div class="card-body small">
							<div class="row mb-3">
								<img class="img-profile rounded-circle w-50 mx-auto text-center" src="../assets/img/undraw_profile.svg">
							</div>
							<div class="text-center">
								<span class="font-weight-bold"><?php echo e($plan['plan_name']); ?></span> <br><br>
								<span class="font-weight-bold txt-md">$<?php echo e(number_format($plan['min_amount'])); ?> - $<?php echo e(number_format($plan['max_amount'])); ?></span> <br>
								FOR <?php echo e($plan['plan_duration']); ?> DAY(S) <br><br>
								<?php echo e(number_format($plan['daily_percentage'])); ?>% Daily Top Up<br>
								Maximum Price $<?php echo e(number_format($plan['max_amount'])); ?><br>
								<?php echo e(number_format($plan['referral_percentage'])); ?>% Referral Percent<br>
								<?php echo e(number_format($plan['bonus_percentage'])); ?>% Trading Bonus<br>
								<a href="#" class="btn btn-primary small btn-icon-split mt-3">
									<span class="icon text-white-50 small">
										<i class="fas fa-plus"></i>
									</span>
									<span class="text small" data-toggle="modal" data-target="#plan<?php echo e($plan['id']); ?>">Purchase Plan</span>
								</a>
								
							</div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</div>
</div>


<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="plan<?php echo e($plan['id']); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content py-3">
			<form action="<?php echo e(route('user.invest.new')); ?>" method="POST" class="px-5">
				<?php echo csrf_field(); ?>
				<input type="text" name="plan_id" value="<?php echo e($plan['id']); ?>" hidden>
				<p class="mx-auto text-center text-dark font-weight-bold small">Purchase Plan</p>
				<p class="mx-auto text-center text-dark font-weight-bold"><?php echo e($plan['plan_name']); ?></p>
				<div class="form-group px-5 mt-5 row">
					<i class="fas fa-dollar-sign pt-1"></i>
					<input type="number" class="px-1 mx-2" name="amount" placeholder="Enter Amount" max="<?php echo e(number_format($plan['max_amount'])); ?>" min="<?php echo e(number_format($plan['min_amount'])); ?>" style="border:none; outline:none; border-bottom:1px solid rgb(78, 78, 78); width:85%;" required>
				</div>
				<div class="form-group px-5 mt-5 row">
					<i class="fas fa-meteor pt-1"></i>
					<input type="text" class="px-1 mx-2" name="coupon_code" placeholder="Enter Coupon Code (Optional)" style="border:none; outline:none; border-bottom:1px solid rgb(78, 78, 78); width:85%;">
				</div>
				<div class="row mt-5 py-3 ">
					<button type="submit" class="btn btn-primary btn-sm mx-auto">Preview</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/plans.blade.php ENDPATH**/ ?>