

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card bg-light text-black shadow mb-3">
		<div class="card-body">
			<p class="font-weight-bold"><?php echo e($deposit_method_name->display_name); ?></p>
			<div class="text-black-50 small">Amount: $<?php echo e($amount); ?> </div>
			<div class="text-black-50 small">Charge: $<?php echo e($deposit_method_charge->fixed_charge_amount); ?></div>
			<div class="text-black-50 small">Total: $<?php echo e(intval($deposit_method_charge->fixed_charge_amount) + intval($amount)); ?></div>
			<form action="<?php echo e(route('user.deposit.create')); ?>" method="POST">
				<input type="text" name="deposit_method" value="<?php echo e($deposit_method); ?>" hidden>
				<input type="text" name="amount" value="<?php echo e($amount); ?>" hidden>
				<input type="text" name="charge" value="<?php echo e($deposit_method_charge->fixed_charge_amount); ?>" hidden>
				<?php echo csrf_field(); ?>
				<div class="row mt-5">
					<button type="submit" class="btn btn-primary btn-icon-split shadow ml-3">
						<span class="icon txt-sm text-white-50">
							<i class="fas fa-copy"></i>
						</span>
						<span class="txt-sm text">Confirm</span>
					</button>
				</div>
			</form>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/user/deposit-preview.blade.php ENDPATH**/ ?>