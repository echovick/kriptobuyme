HERE
<?php /**PATH C:\Users\HP\Documents\Work\laravel\kriptobuyme\resources\views/dashboard.blade.php ENDPATH**/ ?>